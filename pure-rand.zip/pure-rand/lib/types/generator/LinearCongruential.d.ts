import { RandomGenerator } from './RandomGenerator';
export declare const congruential32: (seed: number) => RandomGenerator;
