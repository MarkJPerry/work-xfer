import { RandomGenerator } from './RandomGenerator';
export declare const xorshift128plus: (seed: number) => RandomGenerator;
