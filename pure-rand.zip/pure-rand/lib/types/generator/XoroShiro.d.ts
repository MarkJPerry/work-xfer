import { RandomGenerator } from './RandomGenerator';
export declare const xoroshiro128plus: (seed: number) => RandomGenerator;
