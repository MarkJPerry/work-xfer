import { RandomGenerator } from './RandomGenerator';
export default function (seed: number): RandomGenerator;
