import { RandomGenerator } from '../generator/RandomGenerator';
export declare function unsafeUniformIntDistribution(from: number, to: number, rng: RandomGenerator): number;
