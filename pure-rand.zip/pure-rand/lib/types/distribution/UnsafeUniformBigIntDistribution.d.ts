import { RandomGenerator } from '../generator/RandomGenerator';
export declare function unsafeUniformBigIntDistribution(from: bigint, to: bigint, rng: RandomGenerator): bigint;
