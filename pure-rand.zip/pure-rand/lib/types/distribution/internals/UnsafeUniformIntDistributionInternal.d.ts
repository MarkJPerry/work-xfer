import { RandomGenerator } from '../../generator/RandomGenerator';
export declare function unsafeUniformIntDistributionInternal(rangeSize: number, rng: RandomGenerator): number;
