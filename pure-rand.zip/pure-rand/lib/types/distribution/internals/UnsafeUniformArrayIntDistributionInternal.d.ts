import { RandomGenerator } from '../../generator/RandomGenerator';
import { ArrayInt } from './ArrayInt';
export declare function unsafeUniformArrayIntDistributionInternal(out: ArrayInt['data'], rangeSize: ArrayInt['data'], rng: RandomGenerator): ArrayInt['data'];
